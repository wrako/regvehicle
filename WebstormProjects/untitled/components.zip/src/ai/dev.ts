import { config } from 'dotenv';
config();

import '@/ai/flows/license-plate-auto-suggest.ts';