package sk.zzs.vehicle.management.entity;

// NetworkPoint.java
import jakarta.persistence.*;
import lombok.Data;
import sk.zzs.vehicle.management.enumer.NetworkPointType;

import java.time.LocalDate;

@Entity
@Data
public class NetworkPoint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Stabilný kód/názov podľa vyhlášky (unikátny) */
    @Column(nullable = false, unique = true)
    private String code;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NetworkPointType type;

    /** Platnosť bodu v číselníku (voliteľné) */
    private LocalDate validFrom;
    private LocalDate validTo;

    // getters/setters...
}
