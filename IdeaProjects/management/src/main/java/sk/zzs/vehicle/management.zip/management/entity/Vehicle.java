package sk.zzs.vehicle.management.entity;

import jakarta.persistence.*;
import lombok.Data;
import sk.zzs.vehicle.management.enumer.VehicleStatus;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Unique vehicle ID (SPZ or internal ID)
    @Column(nullable = false, unique = true)
    private String licensePlate;

    @Column(nullable = false)
    private String brand;

    @Column(nullable = false)
    private String model;

    private LocalDate firstRegistrationDate;

    private LocalDate lastTechnicalCheckDate;

    private LocalDate technicalCheckValidUntil;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private VehicleStatus status;



    // relations
    @ManyToOne(optional = false)
    @JoinColumn(name = "provider_id")
    private Provider provider;

    @ManyToOne(fetch = FetchType.LAZY)      // no cascade here
    @JoinColumn(name = "avl_id")
    private AvlDevice avlDevice;

    @ManyToOne(fetch = FetchType.LAZY)      // same for RDST, Provider, etc.
    @JoinColumn(name = "rdst_id")
    private RdstDevice rdstDevice;



    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @JoinColumn(name = "network_point_id")
    private NetworkPoint networkPoint;


    // optional: image / certificate reference
    private String certificateFilePath;

    // getters & setters omitted for brevity

//    @OneToMany(mappedBy = "vehicle", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<VehicleLog> logs;

}
