package sk.zzs.vehicle.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import sk.zzs.vehicle.management.dto.VehicleDto;
import sk.zzs.vehicle.management.dto.VehicleFilter;
import sk.zzs.vehicle.management.service.VehicleService;

import java.time.LocalDate;

@RestController
@RequestMapping("/vehicles")
@CrossOrigin(origins = "*")
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @GetMapping
    public Page<VehicleDto> getVehicles(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String provider,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate stkValidFrom,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate stkValidTo,
            @PageableDefault(size = 20, sort = "id") Pageable pageable
    ) {
        VehicleFilter filter = new VehicleFilter(q, status, provider, stkValidFrom, stkValidTo);
        return vehicleService.search(filter, pageable);
    }

    @PostMapping
    public VehicleDto registerVehicle(@RequestBody VehicleDto vehicle) {
        return vehicleService.registerVehicle(vehicle);
    }

//    @GetMapping
//    public boolean isLicenseUnique(@RequestBody String license) {
//        return vehicleService.registerVehicle(vehicle);
//    }

    @PostMapping("/{id}/edit")
    public VehicleDto editVehicle(@RequestBody VehicleDto vehicle, @PathVariable Long id) {
        return vehicleService.editVehicle(vehicle, id);
    }

    @GetMapping("/{id}")
    public VehicleDto getVehicle(@PathVariable Long id) {
        return vehicleService.getVehicleById(id);
    }
}
