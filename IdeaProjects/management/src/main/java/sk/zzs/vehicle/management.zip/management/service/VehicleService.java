package sk.zzs.vehicle.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sk.zzs.vehicle.management.dto.VehicleDto;
import sk.zzs.vehicle.management.dto.VehicleFilter;
import sk.zzs.vehicle.management.entity.Vehicle;
import sk.zzs.vehicle.management.dto.VehicleMapper;
import sk.zzs.vehicle.management.repository.VehicleRepository;
import sk.zzs.vehicle.management.repository.VehicleSpecifications;

import java.util.List;

@Service
@Transactional
public class VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private VehicleMapper vehicleMapper;

    @Transactional(readOnly = true)
    public List<VehicleDto> getAllVehicles() {
        return vehicleRepository.findAll()
                .stream()
                .map(vehicleMapper::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public Page<VehicleDto> search(VehicleFilter filter, Pageable pageable) {
        return vehicleRepository
                .findAll(VehicleSpecifications.withFilter(filter), pageable)
                .map(vehicleMapper::toDto);
    }

    public VehicleDto registerVehicle(VehicleDto dto) {
        Vehicle entity = vehicleMapper.toEntity(dto);
        Vehicle saved = vehicleRepository.save(entity);
        return vehicleMapper.toDto(saved);
    }

    public VehicleDto editVehicle(VehicleDto dto, Long id) {
        if (id == null) {
            throw new IllegalArgumentException("Vehicle id is required for edit");
        }
        Vehicle entity = vehicleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle with id " + id + " not found"));
        vehicleMapper.copyToEntity(dto, entity);

        Vehicle saved = vehicleRepository.save(entity);

        return vehicleMapper.toDto(saved);
    }

    @Transactional(readOnly = true)
    public VehicleDto getVehicleById(Long id) {
        return vehicleRepository.findById(id)
                .map(vehicleMapper::toDto)
                .orElse(null);
    }
}
