package sk.zzs.vehicle.management.enumer;

public enum OperationType {
    CREATE, UPDATE, DELETE
}
