package sk.zzs.vehicle.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import sk.zzs.vehicle.management.dto.NetworkPointDto;
import sk.zzs.vehicle.management.dto.NetworkPointMapper;
import sk.zzs.vehicle.management.entity.NetworkPoint;
import sk.zzs.vehicle.management.entity.Provider;
import sk.zzs.vehicle.management.repository.NetworkPointRepository;
import sk.zzs.vehicle.management.repository.ProviderRepository;

import java.util.List;

@Service
@Transactional
public class NetworkPointService {
    @Autowired
    private NetworkPointRepository networkPointRepository;

    @Autowired
    private NetworkPointMapper networkPointMapper;

    @Autowired
    private ProviderRepository providerRepository;

    @Transactional(readOnly = true)
    public List<NetworkPointDto> getAllNetworkPoints() {
        return networkPointRepository.findAll()
                .stream()
                .map(networkPointMapper::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public NetworkPointDto getNetworkPointById(Long id) {
        return networkPointRepository.findById(id)
                .map(networkPointMapper::toDto)
                .orElseThrow(() -> CrudUtils.notFound("NetworkPoint", id));
    }

    public NetworkPointDto createNetworkPoint(NetworkPointDto dto) {
        // Provider is required for new network points
        if (dto.getProviderId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Provider is required for network point creation");
        }

        NetworkPoint entity = networkPointMapper.toEntity(dto);

        Provider provider = providerRepository.findById(dto.getProviderId())
                .orElseThrow(() -> CrudUtils.notFound("Provider", dto.getProviderId()));
        entity.setProvider(provider);

        NetworkPoint saved = networkPointRepository.save(entity);
        return networkPointMapper.toDto(saved);
    }

    public NetworkPointDto updateNetworkPoint(Long id, NetworkPointDto dto) {
        NetworkPoint entity = networkPointRepository.findById(id)
                .orElseThrow(() -> CrudUtils.notFound("NetworkPoint", id));

        networkPointMapper.copyToEntity(dto, entity);

        // Set provider if provided
        if (dto.getProviderId() != null) {
            Provider provider = providerRepository.findById(dto.getProviderId())
                    .orElseThrow(() -> CrudUtils.notFound("Provider", dto.getProviderId()));
            entity.setProvider(provider);
        }

        NetworkPoint saved = networkPointRepository.save(entity);
        return networkPointMapper.toDto(saved);
    }

    public void deleteNetworkPoint(Long id) {
        if (!networkPointRepository.existsById(id)) {
            throw CrudUtils.notFound("NetworkPoint", id);
        }

        // NetworkPoints can now be deleted freely since they're not directly referenced by vehicles
        networkPointRepository.deleteById(id);
    }

    // Legacy method for Vehicle service
    public NetworkPoint findById(Long id) {
        return networkPointRepository.getReferenceById(id);
    }
}
