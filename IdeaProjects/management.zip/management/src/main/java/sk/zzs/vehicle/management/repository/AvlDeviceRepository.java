package sk.zzs.vehicle.management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sk.zzs.vehicle.management.entity.AvlDevice;

public interface AvlDeviceRepository extends JpaRepository<AvlDevice, Long> {}
