package sk.zzs.vehicle.management.exception;

public class InvalidVehicleDataException extends RuntimeException {
    public InvalidVehicleDataException(String message) {
        super(message);
    }
}
