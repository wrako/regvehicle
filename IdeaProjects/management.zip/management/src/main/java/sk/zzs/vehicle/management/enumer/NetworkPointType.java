package sk.zzs.vehicle.management.enumer;

// NetworkPointType.java
public enum NetworkPointType {
    RLP, RV, RZP, OTHER
}
