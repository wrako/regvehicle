package sk.zzs.vehicle.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
